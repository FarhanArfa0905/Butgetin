package com.dicoding.butgetin.ui.profile

class ProfileViewModel {
}