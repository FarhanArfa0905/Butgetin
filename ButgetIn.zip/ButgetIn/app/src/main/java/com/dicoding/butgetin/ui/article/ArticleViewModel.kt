package com.dicoding.butgetin.ui.article

class ArticleViewModel {
}