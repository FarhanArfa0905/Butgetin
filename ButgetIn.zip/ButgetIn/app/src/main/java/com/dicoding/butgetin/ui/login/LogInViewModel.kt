package com.dicoding.butgetin.ui.login

class LogInViewModel {
}