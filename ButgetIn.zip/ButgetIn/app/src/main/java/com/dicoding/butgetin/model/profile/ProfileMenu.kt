package com.dicoding.butgetin.model.profile

data class ProfileMenu(
    val icon: Int,
    val name: String
)