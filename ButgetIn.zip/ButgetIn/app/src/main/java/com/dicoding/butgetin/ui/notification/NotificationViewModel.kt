package com.dicoding.butgetin.ui.notification

class NotificationViewModel {
}