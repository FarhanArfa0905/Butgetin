package com.dicoding.butgetin.ui.signup

class SignUpViewModel {
}