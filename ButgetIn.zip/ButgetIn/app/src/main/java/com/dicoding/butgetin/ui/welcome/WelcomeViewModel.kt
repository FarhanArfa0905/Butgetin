package com.dicoding.butgetin.ui.welcome

class WelcomeViewModel {
}